'use strict';

angular.module('markdownApp', [
  'ngAnimate',
  'ngCookies',
  'ngSanitize',
  'ui.router',
  'angularMoment',
  'LocalStorageModule'
]);